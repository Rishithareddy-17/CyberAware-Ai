// Smooth scroll
document.querySelectorAll('[data-scroll], .site-nav a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const href = a.getAttribute('href');
    if (!href || !href.startsWith('#')) return;
    e.preventDefault();
    const target = document.querySelector(href);
    if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
});

// Year
const yearEl = document.getElementById('year');
if (yearEl) yearEl.textContent = new Date().getFullYear();

// Reveal on scroll
const revealEls = Array.from(document.querySelectorAll('[data-reveal], .section .container > *'));
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) entry.target.classList.add('visible');
  });
}, { threshold: 0.08 });
revealEls.forEach(el => observer.observe(el));

// Impact counters
function animateCount(el, to, duration = 1600) {
  const start = 0;
  const startTime = performance.now();
  function tick(now) {
    const p = Math.min(1, (now - startTime) / duration);
    const eased = 1 - Math.pow(1 - p, 3);
    const val = Math.floor(start + (to - start) * eased);
    el.textContent = val.toLocaleString();
    if (p < 1) requestAnimationFrame(tick); else el.textContent = to.toLocaleString();
  }
  requestAnimationFrame(tick);
}
const statObserver = new IntersectionObserver((entries, obs) => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    const num = entry.target.querySelector('.stat-number');
    if (num && !num.dataset.done) {
      num.dataset.done = '1';
      animateCount(num, Number(num.dataset.count || '0'));
    }
    obs.unobserve(entry.target);
  });
}, { threshold: 0.4 });
document.querySelectorAll('.stat').forEach(el => statObserver.observe(el));

// Slider
const slidesWrap = document.querySelector('.slides');
const slides = Array.from(document.querySelectorAll('.slide'));
let idx = 0;
function go(i) {
  idx = (i + slides.length) % slides.length;
  slidesWrap.style.transform = `translateX(${-idx * 100}%)`;
  slidesWrap.style.transition = 'transform 500ms ease';
}
const prev = document.querySelector('.slider .prev');
const next = document.querySelector('.slider .next');
prev && prev.addEventListener('click', () => go(idx - 1));
next && next.addEventListener('click', () => go(idx + 1));
let auto = setInterval(() => go(idx + 1), 5000);
slidesWrap && slidesWrap.addEventListener('pointerdown', () => { clearInterval(auto); });

// Chatbot widget (demo)
const toggle = document.getElementById('chatbot-toggle');
const panel = document.getElementById('chatbot-panel');
const closeBtn = document.querySelector('.chatbot-close');
function setChat(open) {
  if (!panel) return;
  panel.hidden = !open;
  toggle?.setAttribute('aria-expanded', String(open));
}
toggle && toggle.addEventListener('click', () => setChat(panel.hidden));
closeBtn && closeBtn.addEventListener('click', () => setChat(false));

// Animated network lines on hero canvas
(function () {
  const c = document.getElementById('hero-grid');
  if (!c) return;
  const ctx = c.getContext('2d');
  let w, h, points;
  function resize() {
    w = c.width = window.innerWidth;
    h = c.height = window.innerHeight;
    init();
  }
  function init() {
    const cols = Math.ceil(w / 120);
    const rows = Math.ceil(h / 120);
    points = [];
    for (let y = 0; y <= rows; y++) {
      for (let x = 0; x <= cols; x++) {
        points.push({
          x: x * (w / cols) + (Math.random() - .5) * 10,
          y: y * (h / rows) + (Math.random() - .5) * 10,
          vx: (Math.random() - .5) * 0.2,
          vy: (Math.random() - .5) * 0.2,
        });
      }
    }
  }
  function step() {
    ctx.clearRect(0, 0, w, h);
    // draw links
    for (let i = 0; i < points.length; i++) {
      const a = points[i];
      a.x += a.vx; a.y += a.vy;
      if (a.x < 0 || a.x > w) a.vx *= -1;
      if (a.y < 0 || a.y > h) a.vy *= -1;
      for (let j = i + 1; j < i + 18 && j < points.length; j++) {
        const b = points[j];
        const dx = a.x - b.x, dy = a.y - b.y;
        const d2 = dx*dx + dy*dy;
        if (d2 < 140*140) {
          const apha = Math.max(0, 1 - Math.sqrt(d2) / 140) * 0.25;
          const g = ctx.createLinearGradient(a.x, a.y, b.x, b.y);
          g.addColorStop(0, `rgba(0,229,255,${apha})`);
          g.addColorStop(1, `rgba(0,255,136,${apha})`);
          ctx.strokeStyle = g;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(b.x, b.y);
          ctx.stroke();
        }
      }
    }
    requestAnimationFrame(step);
  }
  resize();
  window.addEventListener('resize', resize);
  requestAnimationFrame(step);
})();


